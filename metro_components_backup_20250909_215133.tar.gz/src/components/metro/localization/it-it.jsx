
const it = {
    /* SoundMachine */
    "Start / Stop": "Inizio / Fermare",
    "Instrument": "Strumento",
    "Increase speed": "Aumentare la velocità",
    "BPM range": "BAM gamma",
    "By bar": "Al tatto",
    "bar" :"tatto",
    "By time": "Di tanto in tanto",
    "Set time": "Imposta l'ora"
    
}
export default it;