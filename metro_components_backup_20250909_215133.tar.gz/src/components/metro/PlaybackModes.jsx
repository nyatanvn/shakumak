export const PlaybackModes = {
	STOP: "stop",
	CYCLE: "cycle",
	REPEAT: "repeat",
	CONTINUE: "continue"
};