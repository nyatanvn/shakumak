
// NOTE: If we change any of existing string names we will screw up user presets on client's side
export const PlayModes = {
	BY_BAR: "by_bar",
	BY_TIME: "by_time",
	SET_TIME: "set_time",
	CONSTANT: "constant"
};